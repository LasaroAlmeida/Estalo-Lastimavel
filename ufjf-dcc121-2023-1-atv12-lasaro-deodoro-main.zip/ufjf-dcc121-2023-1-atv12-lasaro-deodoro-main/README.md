# ufjf-dcc121-2023-1-atv12-lasaro-deodoro
### Jogo Estalo Lastimável
### Lásaro de Almeida Deodoro
201835004